from django.urls import path
from . import views


urlpatterns = [
    path('', views.index),  # main page root path
    path('turbo_kits', views.turbo_kits), # pathing to /turbo_kits
    path('supercharger_kits', views.supercharger_kits),  # pathing to /supercharger_kits
]
