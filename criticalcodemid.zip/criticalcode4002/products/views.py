from django.http import HttpResponse
from django.shortcuts import render
from .models import Product


def index(request):  # page request for webserver
    products = Product.objects.all()
    return render(request, 'index.html',
                  {'products': products})  # rendering your html page


def turbo_kits(request):  # /turbo_kits url created
    return HttpResponse('turbo kits')


def supercharger_kits(request):  # /supercharger_kits url created
    return HttpResponse('supercharger kits')
