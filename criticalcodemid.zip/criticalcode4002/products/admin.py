from django.contrib import admin
from .models import Product, Coupon


class CouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount')


class ProductAdmin(admin.ModelAdmin):  # managing common model within the admin area
    list_display = ('name', 'price', 'stock')  # displaying on site


# Register your models here.
admin.site.register(Product, ProductAdmin)  # managing your products in the admin page
admin.site.register(Coupon, CouponAdmin)  # managing Coupons within the admin page
